package com.example.nacosgoodsprovider.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/goods")
public class GoodsController {

    // 注入端口，后续验证负载均衡用
    @Value("${server.port}")
    private String serverPort;

    /**
     * 根据ID查询商品接口
     */
    @GetMapping("/{goodsId}")
    public Map<String, Object> getGoodsById(@PathVariable Long goodsId) {
        Map<String, Object> result = new HashMap<>();
        result.put("goodsId", goodsId);
        result.put("goodsName", "华为Mate手机");
        result.put("price", 4999);
        result.put("serverPort", serverPort);
        return result;
    }
}
