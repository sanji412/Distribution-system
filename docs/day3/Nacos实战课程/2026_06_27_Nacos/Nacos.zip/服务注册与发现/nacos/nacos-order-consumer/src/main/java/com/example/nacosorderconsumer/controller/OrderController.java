package com.example.nacosorderconsumer.controller;

import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Resource
    private RestTemplate restTemplate;

    // 直接用服务名调用，不用写死IP端口
    private static final String GOODS_SERVICE = "http://nacos-goods-provider";

    /**
     * 创建订单：远程调用商品服务查询商品信息
     */
    @GetMapping("/create/{goodsId}")
    public String createOrder(@PathVariable Long goodsId) {
        String url = GOODS_SERVICE + "/goods/" + goodsId;
        Map result = restTemplate.getForObject(url, Map.class);
        return "下单成功，商品信息：" + result;
    }
}
