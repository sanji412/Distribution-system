package com.example.nacosorderconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/**
 * 订单服务启动类
 * @EnableFeignClients：开启OpenFeign功能，自动扫描@FeignClient注解的接口
 */
@SpringBootApplication
@EnableFeignClients // 核心注解：开启Feign客户端扫描
public class NacosOrderConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(NacosOrderConsumerApplication.class, args);
    }

}
