package com.example.nacosorderconsumer.controller;

import com.example.nacosorderconsumer.feign.GoodsFeignClient;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 订单控制器：基于OpenFeign调用商品服务
 */
@RestController
@RequestMapping("/order")
public class OrderController {

    // 注入Feign客户端接口（像注入本地接口一样）
    @Resource
    private GoodsFeignClient goodsFeignClient;

    /**
     * 创建订单：通过Feign接口调用商品服务
     * 对比RestTemplate：无需拼接URL，直接调用接口方法，像调本地方法！
     */
    @GetMapping("/create/{goodsId}")
    public String createOrder(@PathVariable Long goodsId) {
        // 核心：调用Feign接口方法，底层自动完成服务发现、负载均衡、HTTP调用
        Map<String, Object> goodsInfo = goodsFeignClient.getGoodsById(goodsId);
        return "【OpenFeign调用】下单成功，商品信息：" + goodsInfo;
    }
}
/*
    @GetMapping("/create/{goodsId}")
    public String createOrder(@PathVariable Long goodsId) {
        String url = GOODS_SERVICE + "/goods/" + goodsId;
        Map result = restTemplate.getForObject(url, Map.class);
        return "下单成功，商品信息：" + result;
    }
*/
