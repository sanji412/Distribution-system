package com.example.nacosorderconsumer.config;

import feign.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * OpenFeign自定义配置：日志级别
 */
@Configuration
public class FeignConfig {

    /**
     * 配置Feign日志级别：
     * - NONE：不打印日志（默认）；
     * - BASIC：仅打印请求方法、URL、状态码、耗时；
     * - HEADERS：打印BASIC + 请求/响应头；
     * - FULL：打印所有细节（请求/响应头、体、参数）；
     */
    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL; // 开发环境用FULL，生产用BASIC/NONE
    }
}
