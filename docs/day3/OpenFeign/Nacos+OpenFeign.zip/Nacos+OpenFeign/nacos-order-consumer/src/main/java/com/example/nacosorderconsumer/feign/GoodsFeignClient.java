package com.example.nacosorderconsumer.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

/**
 * Feign客户端接口：绑定商品服务的调用规则
 * @FeignClient注解说明：
 *   name/value：指定要调用的服务名（必须和Nacos中商品服务名一致）
 *   url：可选，硬编码地址（测试用，生产禁用）
 */
@FeignClient(name = "nacos-goods-provider") // 对应商品服务的spring.application.name
public interface GoodsFeignClient {

    /**
     * 声明调用商品服务的/goods/{goodsId}接口
     * 注解、参数、返回值必须和商品服务的接口完全一致！
     */
    @GetMapping("/goods/{goodsId}") // 和商品服务GoodsController的接口路径一致
    Map<String, Object> getGoodsById(@PathVariable("goodsId") Long goodsId); // 参数名必须指定，避免映射错误
}