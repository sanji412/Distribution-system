package com.example.nacosgoodsprovider.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @RefreshScope 核心注解：Nacos配置修改后，自动刷新当前类的配置值
 */
@RestController
@RequestMapping("/goods")
@RefreshScope
public class GoodsController {

    @Value("${server.port}")
    private String serverPort;

    // 读取远程Nacos中的自定义配置
    @Value("${goods.stock:0}")
    private Integer goodsStock;

    @Value("${goods.desc:默认描述}")
    private String goodsDesc;

    @GetMapping("/{goodsId}")
    public Map<String, Object> getGoodsById(@PathVariable Long goodsId) {
        Map<String, Object> result = new HashMap<>();
        result.put("goodsId", goodsId);
        result.put("goodsName", "华为Mate手机");
        result.put("price", 4999);
        result.put("stock", goodsStock);
        result.put("desc", goodsDesc);
        result.put("serverPort", serverPort);
        return result;
    }

    /**
     * 测试配置读取接口
     */
    @GetMapping("/config")
    public String testConfig() {
        return "库存：" + goodsStock + "，描述：" + goodsDesc;
    }
}